// import React, { useState } from 'react'
import axios from 'axios'
import styles from './Book.module.css'

const Book = () => {
  const search = window.location?.search ?? ''
  const params = new URLSearchParams(search)
  const price = params.get('price')
  const movieId = params.get('id')
  const [totalPrice, setTotalPrice] = useState(params.get('price'))
  const [bookingMsg, setBookingMsg] = useState('');
  const [errorMessage, setErrorMessage] = useState("")
  const [paymentForm, setPaymentForm] = useState({
    email: '',
    phone: '',
    seat: 1
  })
  const { seat, email, phone } = paymentForm

  const onChangeHandler = (e) => {
    const {
      target: { value, name }
    } = e
    setPaymentForm({
      ...paymentForm,
      [name]: value
    })
    name === 'seat' && setTotalPrice(price * value)
  }

  const validation = () => {
    if (!paymentForm.email || !paymentForm.phone || !paymentForm.seat) {
      return "*Please fill the all fields."
    }
  }

  const onSubmitHandler = () => {
    let errorMsg = validation();
    if (!errorMsg) {
      setErrorMessage(errorMsg);
      const submittedData = { ...paymentForm, movieId, totalPrice: totalPrice }
     
      axios
      .post("http://localhost:6565/tickets", submittedData)
      .then(res => console.log(res))
      .catch(err => console.log(err));

        
      alert(`Booking details submitted ${JSON.stringify(submittedData)}`)
      setBookingMsg(" Your booking is confirmed.");
      setPaymentForm({
        email: '',
        phone: '',
        seat: 1
      })
    } else {
      setErrorMessage(errorMsg);
      setBookingMsg(" Your ticket is not booked.");
    }
  }


  return (
    <div>
      <div className={styles.Book}>
        <h3>Book Show</h3>

        <p className='bookingStatus'>{bookingMsg}</p>

        <fieldset>
          <legend>Details</legend>
          <div>
            <label>Phone</label>
          </div>
          <div>
            <input
              type='text'
              id='phone'
              name='phone'
              value={phone == null ? '' : phone}
              onChange={onChangeHandler}
              required
            />
          </div>

          <div>
            <label>Email</label>
          </div>
          <div>
            <input
              type='email'
              id='email'
              name='email'
              value={email == null ? '' : email}
              onChange={onChangeHandler}
              required
            />
          </div>
          <div>
            <label>Seat</label>
          </div>
          <div>
            <input
              type='number'
              id='seat'
              name='seat'
              value={seat == null ? '' : seat}
              onChange={onChangeHandler}
              required
            />
          </div>
          <div>
            <label>Price (Per Seat)</label>
          </div>
          <div>
            <input
              type='number'
              id='price'
              name='price'
              value={price == null ? '' : price}
              onChange={onChangeHandler}
              required
            />
          </div>
          <div>
            <label>Price (Total)</label>
          </div>
          <div>
            <input
              type='number'
              id='totalPrice'
              name='totalPrice'
              value={totalPrice == null ? '' : totalPrice}
              onChange={onChangeHandler}
              required
            />
          </div>
          <div style={{ color: 'red' }}>
            {errorMessage}
          </div>
          <div>
            <input id='submit' type='button' value={'Submit'} onClick={onSubmitHandler} />
          </div>

        </fieldset>
      </div>
    </div>
  )
}


export default Book
